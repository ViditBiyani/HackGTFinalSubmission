//
//  learningiOSApp.swift
//  learningiOS
//
//  Created by Uday Goyat on 10/13/23.

import SwiftUI

@main
struct FinalHackGTApp: App {
    
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

